import tensorflow as tf
print(tf.VERSION)
